<template>
	<div>
		<div id='loading'>
	        <div class="loading-3">
	            <i></i>
	            <i></i>
	            <i></i>
	            <i></i>
	            <i></i>
	            <i></i>
	            <i></i>
	            <i></i>
	        </div>
	        <p class="loading-text">网络加载中...</p>
	    </div>
	    <div class='cover'></div>
	</div>
    
</template>

<script>
</script>

<style>
</style>