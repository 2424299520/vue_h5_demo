<template>
</template>

<script>
	export default {
	  name: 'blank',
	  data () {
		this.$router.replace('setBindPay')
	    return {
			
	    }
	  },
	
	}
</script>

<style>
</style>